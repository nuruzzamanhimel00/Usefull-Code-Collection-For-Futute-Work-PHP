// custom all function here
$.noConflict();

$(document).ready(function(){
    
});
